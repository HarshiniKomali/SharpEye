const express = require('express');
const mongodb = require('mongodb');
//var mongo_data = require('../mongo-data');
const app = express();
//let MongoClient = require('mongodb').MongoClient;
const url = "mongodb+srv://harshini73:Qwerty_73@cluster0.ilywtgu.mongodb.net/sharpeye";
const mongoClient = mongodb.MongoClient;
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: 'true' }));
app.use(bodyParser.json()); // parse application/json
app.use(bodyParser.json({ type: 'application/vnd.api+json' }));

app.listen(3000, () => console.log('Server running on port 3000!'))

app.get('/popular_shirts', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_shirts');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_skirts', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_skirts');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_pants', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_pants');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_handbags', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_handbags');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_earrings', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_earrings');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_shoes', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_shoes');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_shorts', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_shorts');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_necklaces', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_necklaces');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_earrings', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_earrings');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
});
app.get('/popular_sunglasses', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('popular_sunglasses');
        const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var result = []
        for (var i = 0; i < findResult.length;i++) {
            var element = {}
            const r = await coll.find({product:findResult[i]['ProductID']}, {product:1, _id:0,product_urls:1,search_links:0}).toArray();
            console.log(r);
            element['product'] = r[0]['product'];
            element['product_urls'] = r[0]['product_urls'];
            result.push(element);
            
        }
        res.send(result);
    });
    
});

app.get('/similar_pants/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_pants');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_sunglasses/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_sunglasses');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_shirts/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_tops');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_shoes/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_shoes');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_skirts/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_skirts');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_shorts/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_shorts');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_earrings/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_earrings');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_handbags/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_handbags');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_necklaces/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_necklaces');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});

app.get('/similar_coats/:productID', (req, res) => {
    mongoClient.connect(url,async function(err, db) {
        if (err) throw err;
        const dbo = db.db("sharpeye");
        console.log("sharpeye")
        const collection = dbo.collection('similar_coats');
        //const findResult = await collection.find().sort({'Mean Rating':-1}).limit(10).toArray();
        const coll = dbo.collection('products');
        //console.log('Found documents =>', findResult);
        var product_info = []
        result = await collection.find({id:req.params.productID}).toArray();
        
        var element = {};
        console.log(result[0])
        const r1 = await coll.find({product:result[0]['Top 1']}).toArray();
        element['product'] = r1[0]['product'];
        element['product_urls'] = r1[0]['product_urls'];
        product_info.push(element);
        //var result = [];
        var element = {};
        const r2 = await coll.find({product:result[0]['Top 2']}).toArray();
        element['product'] = r2[0]['product'];
        element['product_urls'] = r2[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r3 = await coll.find({product:result[0]['Top 3']}).toArray();
        element['product'] = r3[0]['product'];
        element['product_urls'] = r3[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r4= await coll.find({product:result[0]['Top 4']}).toArray();
        element['product'] = r4[0]['product'];
        element['product_urls'] = r4[0]['product_urls'];
        product_info.push(element);
        //var result = []
        var element = {};
        const r5 = await coll.find({product:result[0]['Top 5']}).toArray();
        element['product'] = r5[0]['product'];
        element['product_urls'] = r5[0]['product_urls'];
        product_info.push(element);
        res.send(product_info);
    });
    
});